
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void prime(int fd){
    int ll;
    if(read(fd, &ll, sizeof(ll)) <= 0){
        exit(0);
    }
    int p[2];
    pipe(p);

    if(fork() == 0){
        close(p[1]);
        prime(p[0]);
        close(p[0]);
        exit(0);
    }else{
        close(p[0]);
        printf("prime %d\n", ll);
        int num;
        while(read(fd, &num, sizeof(num)) > 0){
            if(num % ll != 0){
                write(p[1], &num, sizeof(num));
            }
            
        }
        close(fd);
        close(p[1]);
        wait(0);
        exit(0);
    }
}
int main(int argc, char *argv[]){
    
    int p[2];

    pipe(p);

    
    if(fork() == 0){
        close(p[1]);
        prime(p[0]);
        close(p[0]);
        exit(0);
    }else{
        close(p[0]);
        for(int i = 2; i <= 35; ++i){
            write(p[1], &i, sizeof(i));
        }
        close(p[1]);
        wait(0);
        exit(0);
    }

}

