#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
  
void find(char *path, char *target){
    char buf[512], *p;
    int fd;
    struct stat st;
    struct dirent de;

    memset(buf, 0, sizeof(buf));

    if((fd = open(path, 0)) < 0){
        fprintf(2, "find: cannot open %s\n", path);
        return;
    }
    if(fstat(fd, &st) < 0){
        fprintf(2, "find: cannot stat %s\n", path);
        close(fd);
        return;
    }


    if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
      printf("find: path too long\n");
      close(fd);
      return;
    }


    while(read(fd, &de, sizeof(de)) == sizeof(de)){
	if (de.inum == 0)
            continue;

	if (strcmp(de.name, ".") == 0 || strcmp(de.name, "..") == 0)
            continue;
        strcpy(buf, path);
        p = buf + strlen(buf);
        *p++ = '/';
	strcpy(p, de.name);


        if(stat(buf, &st) < 0){
            printf("find: cannot stat %s\n", buf);
            continue;
        }

        if(st.type == T_DIR){
            find(buf, target);
        }else if(st.type == T_FILE){
            if(strcmp(de.name, target) == 0){
                printf("%s\n", buf);
            }

        }

    }

	close(fd);


    
    
      
}

int main(int argc, char *argv[]){

    if(argc != 3){
        fprintf(2, "Usage: find <directory> <filename>\n");
        exit(1);
    }
    find(argv[1], argv[2]);
    exit(0);
}

