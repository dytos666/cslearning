#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char *argv[]){

    int p[2];
    int p2[2];
    char buf;
    pipe(p);
    pipe(p2);
    if(fork() == 0){
	close(p[1]);
	close(p2[0]);

        read(p[0], &buf, sizeof(buf));
        printf("%d: received ping\n", getpid());

        write(p2[1], "h", 1);
	exit(0);
    }else{
	close(p2[1]);
        close(p[0]);

        write(p[1], "h", 1);
        read(p2[0], &buf, sizeof(buf));

        printf("%d: received pong\n", getpid());
	exit(0);
    }
    return 0;
}

