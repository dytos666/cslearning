
#include "kernel/param.h"
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"


void xargs_exec(char *cmd, char *argv[]){
    if(fork() == 0){
        if (exec(cmd, argv) == -1) {
            printf("\nexec faild, not found the %s!\n\n", argv[0]);
        }
        exit(0);
    }
}

int main(int argc, char *argv[]){

    if (argc < 2) {
        fprintf(2, "Usage: <command> <params> | xargs <command>  <params>\n");
        exit(1);
    }

    if (argc > MAXARG) {
        fprintf(2, "Usage: <command> <params> | xargs <command>  <params>\n");
        exit(1);
    }

    char buf[512];
    char *args[MAXARG];
    char  *p = buf, *endp = buf;

    int index = 0;

    for(int i = 1; i < argc; ++i){
        args[index++] = argv[i];

    }
    char *cmd = argv[1];
    int now_index = index;
    

    while(read(0, p, 1) > 0){
        if(*p == ' ' || *p == '\n'){
	    char c = *p;
            *p = '\0';
            args[now_index++] = endp;
            endp = p + 1;

	    if(c == '\n'){
		args[now_index] = 0;
		xargs_exec(cmd, args);
		now_index = index;
	    }

        }
        p++;
    }

    wait(0);
    exit(0);




}

