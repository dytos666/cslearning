// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"
struct spinlock ref_lock;
void descr(uint64);
void alloc_arr();
void freerange(void *pa_start, void *pa_end);
uint64 getindex(uint64 pa);


extern char end[]; // first address after kernel.
                   // defined by kernel.ld.


struct run {
  struct run *next;
};

struct {
  struct spinlock lock;
  struct run *freelist;
  char *arr;
  char *end;
} kmem;

void
kinit()
{
  initlock(&kmem.lock, "kmem");
  alloc_arr();
  freerange(kmem.end, (void*)PHYSTOP);
}

void
freerange(void *pa_start, void *pa_end)
{
  char *p;
  p = (char*)PGROUNDUP((uint64)pa_start);
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    kfree(p);
}

// Free the page of physical memory pointed at by v,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    panic("kfree");

  // Fill with junk to catch dangling refs.
  if((uint64)kmem.arr[getindex((uint64)pa)] > 1){

	  descr((uint64)pa);
	  return;
  }

  if((uint64)kmem.arr[getindex((uint64)pa)] == 1)
	  descr((uint64)pa);
  memset(pa, 1, PGSIZE);
  r = (struct run*)pa;

  acquire(&kmem.lock);
  r->next = kmem.freelist;
  kmem.freelist = r;
  release(&kmem.lock);
}


// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
  struct run *r;

  acquire(&kmem.lock);
  r = kmem.freelist;
  if(r)
    kmem.freelist = r->next;
  release(&kmem.lock);

  if(r){
	  kmem.arr[getindex((uint64)r)] = 1;
  }

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk

  return (void*)r;
}


void alloc_arr(){
	kmem.arr = (char *)PGROUNDUP((uint64)end);
	char *p = kmem.arr;
	uint64 pgsize = (PHYSTOP - KERNBASE + PGSIZE - 1) / PGSIZE;
	memset(p, 0,pgsize);
	kmem.end = (char*)((uint64)kmem.arr + pgsize);
}
void incur(uint64 pa){
	acquire(&ref_lock);
        kmem.arr[getindex(pa)]++;
	release(&ref_lock);

}
void descr(uint64 pa){
	acquire(&ref_lock);
        kmem.arr[getindex(pa)]--;
	release(&ref_lock);

}

uint64 getindex(uint64 pa){
	return (pa - KERNBASE) / PGSIZE;
}
