// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

void freerange(void *pa_start, void *pa_end, uint64 i);

extern char end[]; // first address after kernel.
                   // defined by kernel.ld.
int prinsz(int);

struct run {
  struct run *next;
};

struct {
  struct spinlock lock[NCPU];
  struct run *freelist[NCPU];
  struct spinlock mlock;
} kmem;

void
kinit()
{

  for(int i = 0; i < NCPU; ++i){
      char buf[10] = {0};
      snprintf(buf, sizeof("kmem") + sizeof(int), "kmem%d", i); 
      kmem.freelist[i] = 0;

      initlock(&kmem.lock[i], buf);
  }
  
  uint64 sz = (PHYSTOP - (uint64)end) / NCPU;
  for(uint64 i = 0; i < NCPU; ++i){
      freerange((void*)(i * sz + end), (void*)((i + 1) * sz + (uint64)end), i);

  }

}
int prinsz(int i){
    struct run *r = (struct run*)kmem.freelist[i];
    int sz = 0;
    while(r){
        r = r->next;
        sz++;
    }
    return sz;

}

void
freerange(void *pa_start, void *pa_end, uint64 i)
{
  char *p;
  struct run *r;
  p = (char*)PGROUNDUP((uint64)pa_start);
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE){
      r = (struct run*)p;
      r->next = kmem.freelist[i];
      kmem.freelist[i] = r;
  }

}

// Free the page of physical memory pointed at by v,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
  struct run *r;
  push_off();
  int id = cpuid();
  pop_off();


  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);

  r = (struct run*)pa;

  acquire(&kmem.lock[id]);
  r->next = kmem.freelist[id];
  kmem.freelist[id] = r;
  release(&kmem.lock[id]);
}

// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
  struct run *r;

  push_off();
  int id = cpuid();

  acquire(&kmem.lock[id]);
  r = kmem.freelist[id];
  //printf("kalloc %p\n", r);
  if(r)
    kmem.freelist[id] = r->next;
  else{
      //release(&kmem.lock[id]);
      for(int i = NCPU - 1; i >= 0; --i){
          if(kmem.freelist[i] == 0) continue;
          acquire(&kmem.lock[i]);

          //kmem.freelist[id] = kmem.freelist[i];
          //kmem.freelist[i] = 0;
          //r = kmem.freelist[id];
          //kmem.freelist[id] = r->next;
          r = kmem.freelist[i];
          kmem.freelist[i] = r->next;
          release(&kmem.lock[i]);
          break;

      }
      //acquire(&kmem.lock[id]);
  }
  release(&kmem.lock[id]);

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
  pop_off();
  return (void*)r;
}





