// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.


#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

#define HASHNUM 13

int hash(int);
int hash_evict(int dev, int index);

struct {
  struct spinlock lock;
  struct buf buf[NBUF];
  struct buf map[HASHNUM];
  struct spinlock lock_map[HASHNUM];

  // Linked list of all buffers, through prev/next.
  // Sorted by how recently the buffer was used.
  // head.next is most recent, head.prev is least.
  struct buf head;
} bcache;

int print_map_lock(int index){
    int sz = 0;
    index %= HASHNUM;
    struct buf *b = bcache.map[index].next;
    while(b){
        b = b->next;
        sz++;
    }
    return sz;
}

void
binit(void)
{

  initlock(&bcache.lock, "bcache");

  // Create linked list of buffers
  for(int i = 0; i < HASHNUM; i++){
      char buf[10] = {0};
      snprintf(buf, sizeof("bcache") + sizeof(int), "bcache%d", i);
      bcache.map[i].next= 0;

    initlock(&bcache.lock_map[i], buf);
  }
  for(int i = 0; i < NBUF; ++i){
      struct buf *b = &bcache.buf[i];
      memset(b, 0, sizeof(struct buf));
      b->blockno = (uint)-1;
      b->dev = (uint)-1;
      initsleeplock(&b->lock, "buffer");
      int key = hash(i);
      b->next = bcache.map[key].next;
      bcache.map[key].next = b;
      b->ticks = 0;
  }
}

// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{

    int key = hash(blockno);

  // Is the block already cached?
    acquire(&bcache.lock_map[key]);
    //uint ticks = ~(0x0);

    struct buf *b = bcache.map[key].next;
    while(b){
        if(b->dev == dev && b->blockno == blockno){
            b->refcnt++;
            release(&bcache.lock_map[key]);
            acquiresleep(&b->lock);
            return b;
        }
        b = b->next;
    }

  // not find look for current block ;
    b = bcache.map[key].next;
    struct buf *least_use = 0;
    while (b) {
        if(b->refcnt == 0 && (least_use == 0 || least_use->ticks < b->ticks)){
            least_use = b;
        }
        b = b->next;
    }
    if(least_use){
        least_use->blockno = blockno;
        least_use->refcnt = 1;
        least_use->dev = dev;
        least_use->valid = 0;
        release(&bcache.lock_map[key]);
        acquiresleep(&least_use->lock);
        return least_use;
    }


    release(&bcache.lock_map[key]);

    //not find in this block , steal from other place
    acquire(&bcache.lock);

    acquire(&bcache.lock_map[key]);
    b = bcache.map[key].next;
    while(b){
        if(b->dev == dev && b->blockno == blockno){
            b->refcnt++;
            release(&bcache.lock_map[key]);
            release(&bcache.lock);
            acquiresleep(&b->lock);
            return b;
        }
        b = b->next;
    }
    release(&bcache.lock_map[key]);

 
    int index = (key + 1) % HASHNUM;

    while(key != index){

        acquire(&bcache.lock_map[index]);
        b = bcache.map[index].next;
        least_use = 0;
        struct buf *prev = &bcache.map[index], *prev_ans;
        while (b) {
            if(b->refcnt == 0 && (least_use == 0 || least_use->ticks < b->ticks)){
                prev_ans = prev;
                least_use = b;
            }
            prev = prev->next;
            b = b->next;
        }
        if(least_use){
            least_use->blockno = blockno;
            least_use->refcnt = 1;
            least_use->dev = dev;
            least_use->valid = 0;
            prev_ans->next = least_use->next;
            release(&bcache.lock_map[index]);

            acquire(&bcache.lock_map[key]);
            
            least_use->next = bcache.map[key].next;
            bcache.map[key].next = least_use;

            release(&bcache.lock_map[key]);

            release(&bcache.lock);
            acquiresleep(&least_use->lock);
            return least_use;
        }
    
        release(&bcache.lock_map[index]);
        index = (index + 1) % HASHNUM;
    }



  panic("bget: no buffers");
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("bwrite");
  virtio_disk_rw(b, 1);
}

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("brelse");

  releasesleep(&b->lock);

  int index = hash(b->blockno);
  acquire(&bcache.lock_map[index]);

  b->refcnt--;
  if(b->refcnt == 0)
      b->ticks = getticks();

  release(&bcache.lock_map[index]);
}

void
bpin(struct buf *b) {

  int index = hash(b->blockno);
  acquire(&bcache.lock_map[index]);
  b->refcnt++;
  release(&bcache.lock_map[index]);
}

void
bunpin(struct buf *b) {
  int index = hash(b->blockno);
  acquire(&bcache.lock_map[index]);

  b->refcnt--;
  release(&bcache.lock_map[index]);
}



int hash(int i){
    return i % HASHNUM;
}
